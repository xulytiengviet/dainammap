# Đại Nam Map · 1838 ↔ Việt Nam 2025

WebGIS so sánh ảnh bản đồ Đại Nam Quốc (ảnh ghi **1838**) và bản đồ Việt Nam hiện đại. Tham khảo cách tiếp cận giao diện từ [`xulytiengviet/maparchive`](https://github.com/xulytiengviet/maparchive).

## Chạy

Đặt toàn bộ `index.html`, `assets/` cùng nhau. Mở bằng web server (không dùng `file://`):

```bash
python -m http.server 8080
```

Truy cập `http://localhost:8080`, hoặc bật GitHub Pages từ `/ (root)` nhánh `main`.

## Dữ liệu / độ chính xác

- `assets/dai-nam-1838-source.png`: toàn bộ ảnh được người dùng cung cấp, không cắt hoặc can thiệp đường biên.
- `assets/dai-nam-image-space.pmtiles`: **PMTiles v3 JPEG raster**, 85 tile (z0–z3) theo hệ tọa độ **ảnh**, KHÔNG georeference; hiển thị bằng Leaflet `CRS.Simple` + PMTiles JavaScript SDK.
- Cột hiện đại: OpenStreetMap, EPSG:3857, địa danh tham chiếu WGS84.
- Nút chọn địa danh cho phép *đối chiếu vị trí gợi ý* chứ không phải tọa độ kiểm định. Những điểm ảnh ví dụ trong `cities` phải được hiệu chỉnh khi khảo đính.
- Ảnh ghi “1838” và “Minh Mệnh năm thứ 18”, có sự không thống nhất cần khảo cứu, **không thể tự gắn năm 1835**.
- Để chồng hai bản đồ theo tọa độ chính xác, phải tìm nguồn lịch sử gốc, chọn và kiểm định GCP, warp GeoTIFF sang EPSG:3857, kiểm tra RMSE và xuất PMTiles georeferenced. Không áp dụng phép transform giả định từ hình minh họa.

## Tạo lại PMTiles

```bash
python -m pip install pillow
python tools/build_pmtiles.py assets/dai-nam-1838-source.png assets/dai-nam-image-space.pmtiles
```

Định dạng archive tuân thủ PMTiles v3, metadata ghi rõ image-space. Khi chạy trên GitHub Pages, server cần hỗ trợ HTTP Range. GitHub Pages hỗ trợ tải tĩnh; nếu gặp vấn đề Range hãy chuyển `.pmtiles` sang object storage cấu hình CORS và Range.

## Công nghệ & giấy phép

Leaflet (BSD-2-Clause), PMTiles (BSD-3-Clause), OpenStreetMap (ODbL attribution). Mã ứng dụng: MIT © 2026 Long Ngo. **Ảnh lịch sử là tài liệu riêng**; chưa xác minh giấy phép, nguồn gốc, niên đại; MIT không áp dụng cho ảnh.
